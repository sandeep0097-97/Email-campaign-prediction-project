"""
index.py - the web app (Flask). Vercel runs this file as a serverless function.

Routes
  GET  /             -> the prediction web page (api/templates/index.html)
  POST /api/predict  -> JSON in, prediction out
  GET  /api/health   -> quick check that the model loads

Run locally:  python api/index.py   then open http://127.0.0.1:5000
"""
import os
import sys

import joblib
from flask import Flask, jsonify, request, send_file

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)  # so "features" can be imported both locally and on Vercel
from features import CLASS_NAMES, NUMERIC_FEATURES, prepare_features  # noqa: E402

MODEL_PATH = os.path.join(HERE, "model.joblib")
PAGE_PATH = os.path.join(HERE, "templates", "index.html")

app = Flask(__name__)
_model = None


def get_model():
    """Load the model once and reuse it (faster for later requests)."""
    global _model
    if _model is None:
        _model = joblib.load(MODEL_PATH)
    return _model


# Allowed ranges, so the API rejects obviously wrong input with a clear message
VALID_RANGES = {
    "Email_Type": (1, 2),
    "Subject_Hotness_Score": (0, 5),
    "Email_Source_Type": (1, 2),
    "Email_Campaign_Type": (1, 3),
    "Total_Past_Communications": (0, 500),
    "Time_Email_sent_Category": (1, 3),
    "Word_Count": (0, 10000),
    "Total_Links": (0, 500),
    "Total_Images": (0, 500),
}
OPTIONAL = {"Total_Past_Communications", "Total_Links", "Total_Images"}


def validate(record):
    errors = []
    for col in NUMERIC_FEATURES:
        value = record.get(col)
        if value in (None, ""):
            if col not in OPTIONAL:
                errors.append(f"{col} is required.")
            continue
        try:
            number = float(value)
        except (TypeError, ValueError):
            errors.append(f"{col} must be a number.")
            continue
        low, high = VALID_RANGES[col]
        if not low <= number <= high:
            errors.append(f"{col} must be between {low} and {high}.")
    return errors


@app.get("/")
def home():
    return send_file(PAGE_PATH)


@app.get("/api/health")
def health():
    get_model()
    return jsonify({"status": "ok"})


@app.post("/api/predict")
def predict():
    record = request.get_json(silent=True)
    if not isinstance(record, dict):
        return jsonify({"error": "Send a JSON object with the email's details."}), 400

    errors = validate(record)
    if errors:
        return jsonify({"error": " ".join(errors)}), 400

    model = get_model()
    X = prepare_features([record])
    probabilities = model.predict_proba(X)[0]
    predicted = int(probabilities.argmax())
    return jsonify({
        "prediction": predicted,
        "label": CLASS_NAMES[predicted],
        "probabilities": {CLASS_NAMES[int(c)]: round(float(p), 4)
                          for c, p in zip(model.classes_, probabilities)},
    })


if __name__ == "__main__":
    app.run(debug=True)
