"""
features.py - shared feature preparation.

Used by BOTH the training script (src/train_model.py) and the web API (api/index.py),
so the model always sees data in exactly the same shape. It uses only NumPy (no pandas),
which keeps the Vercel deployment small.
"""
import numpy as np

# Raw numeric inputs, in the exact order the model expects
NUMERIC_FEATURES = [
    "Email_Type",                 # 1 or 2
    "Subject_Hotness_Score",      # 0.0 - 5.0
    "Email_Source_Type",          # 1 or 2
    "Email_Campaign_Type",        # 1, 2 or 3
    "Total_Past_Communications",  # count (may be missing)
    "Time_Email_sent_Category",   # 1 = morning, 2 = afternoon, 3 = evening
    "Word_Count",
    "Total_Links",                # may be missing
    "Total_Images",               # may be missing
]

# Customer_Location is a letter A-G, or missing. We one-hot encode it by hand.
LOCATIONS = ["A", "B", "C", "D", "E", "F", "G", "Unknown"]

FEATURE_NAMES = NUMERIC_FEATURES + [f"Location_{loc}" for loc in LOCATIONS]

CLASS_NAMES = {0: "Ignored", 1: "Read", 2: "Acknowledged"}


def _to_float(value):
    """Convert a value to float; blanks / None / NaN become np.nan (imputed later)."""
    if value is None:
        return np.nan
    if isinstance(value, str) and value.strip() == "":
        return np.nan
    try:
        return float(value)
    except (TypeError, ValueError):
        return np.nan


def _clean_location(value):
    if value is None or (isinstance(value, float) and np.isnan(value)):
        return "Unknown"
    loc = str(value).strip().upper()
    return loc if loc in LOCATIONS[:-1] else "Unknown"


def prepare_features(records):
    """
    Turn a list of dicts (one per email) into a 2-D NumPy array.

    Missing numeric values are left as NaN; the model pipeline's
    SimpleImputer fills them with the training median.
    """
    rows = []
    for rec in records:
        numeric = [_to_float(rec.get(col)) for col in NUMERIC_FEATURES]
        loc = _clean_location(rec.get("Customer_Location"))
        one_hot = [1.0 if loc == name else 0.0 for name in LOCATIONS]
        rows.append(numeric + one_hot)
    return np.array(rows, dtype=float)
